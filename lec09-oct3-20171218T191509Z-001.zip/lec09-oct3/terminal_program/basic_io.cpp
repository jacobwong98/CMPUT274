// compile with:
//   g++ basic_io.cpp -o basic_io
// to run:
//   ./basic_io

/* key differences with the Arduino
	cin/cout vs Serial.read()/Serial.write()
	int types are different sizes:
		int here is 32 bits, int on an Arduino is 16 bits
		no uint32_t and friends by default, #include <ctypes>
		flush output for cout with endl (also prints '\n')
		no '\r' needed here
		cin will null-terminate character arrays
*/


#include <iostream> // not available in an Arduino program

using namespace std;

int main() {
	int a, b;

	// read in a and then b

	// read in a, ignoring leading whitespaces (eg. ' ', '\n')
	cin >> a >> b;

	// output a+b
	//cout << (a+b) << '\n'; // no '\r' needed with cout
	cout << (a+b) << endl; // prints '\n' and flushes
	// cout << flush; // forces a flush, but endl also flushes

	char str[16];
	cin >> str;
	cout << "the input string: " << str << endl;

	return 0;
}
