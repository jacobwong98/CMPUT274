#include <iostream>
#include <queue>
#include <string>

using namespace std;

int main() {
	queue<int> fred;

	fred.push(7);
	fred.push(5);
	fred.push(3);

	cout << "Size of fred: " << fred.size() << endl;

	cout << "Front of fred: " << fred.front() << endl;
	cout << "Back of fred: " << fred.back() << endl;

	while (!fred.empty()) {
		cout << "Popping: " << fred.front() << endl;
		fred.pop();
	}

	queue<string> sally;
	sally.push("first");
	sally.push("second");
	sally.push("third");

	cout << endl << "Clearing out the queue 'sally':" << endl;
	while (!sally.empty()) {
		cout << "Popping: " << sally.front() << endl;
		sally.pop();
	}

	return 0;
}
