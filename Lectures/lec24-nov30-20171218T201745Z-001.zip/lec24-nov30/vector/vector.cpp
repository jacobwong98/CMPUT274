// must compile with the flag -std=c++11
// e.g.. g++ vector.cpp -o vector -Wall -std=c++11

#include <iostream>
#include <vector>

using namespace std;

int main() {
	// a vector with 0 entries
	vector<int> vec;

	// a vector with 10 entries, all initialized to 2
	vector<int> biggervec(10, 2);

	biggervec[3] = 7;
	biggervec[9] = 0;
	//biggervec[-1] = 4; guaranteed segfault

	biggervec.resize(12);
	biggervec[10] = 10;
	biggervec[11] = 11;

	for (unsigned int i = 0; i < biggervec.size(); ++i) {
		cout << biggervec[i] << ' ';
	}
	cout << endl;

	biggervec.resize(7);

	cout << endl << "Iterating using an iterator: " << endl;
	for (vector<int>::iterator it = biggervec.begin();
			 it != biggervec.end(); ++it) { // c++11
				 cout << *it << ' ';
			 }
	cout << endl;

	cout << endl << "Iterating using auto: " << endl;
	for (auto it = biggervec.begin(); it != biggervec.end(); ++it) {
		cout << *it << ' ';
	}
	cout << endl;

	// for (int& x : biggervec) {
	// 	x = 1;
	// }

	cout << endl << "Range-based for loop: " << endl;
	for (int x : biggervec) { //c++11
		cout << x << ' ';
	}
	cout << endl;

	return 0;
}
