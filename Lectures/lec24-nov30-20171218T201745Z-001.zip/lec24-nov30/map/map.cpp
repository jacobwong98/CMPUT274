#include <iostream>
#include <unordered_map>
#include <map>
#include <string>

using namespace std;

int main() {
	unordered_map<string, int> grades;

	grades["Zac"] = 77;
	grades["Zach"] = 78;
	grades["Paul"] = 88;

	for (auto entry : grades) {
		cout << entry.first << " has grade " << entry.second << endl;
	}

	grades["Zac"] = 79;

	for (auto entry : grades) {
		cout << entry.first << " has grade " << entry.second << endl;
	}

	auto it = grades.find("Paul");
	if (it != grades.end()) {
		cout << "The grade for " << it->first << " is " << it->second << endl;
	}

	auto it2 = grades.find("Everton");
	if (it2 == grades.end()) {
		cout << "not found" << endl;
	}

	map<string, int> omap;
	omap["Zac"] = 77;
	omap["Zach"] = 78;
	omap["Paul"] = 88;
	for (auto entry : omap) {
		cout << entry.first << " has grade " << entry.second << endl;
	}

	return 0;
}
