#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
	vector<int> v = {5, 2, 7, 8, 1, 0};

	for (auto x : v) {
		cout << x << ' ';
	}
	cout << endl;

	sort(v.begin(), v.end());

	for (auto x : v) {
		cout << x << ' ';
	}
	cout << endl;

	int array[] = {5, 9, 3, 1, 0, 2, 6, 1};
	sort(array, array+8);
	for (auto x : array) {
		cout << x << ' ';
	}
	cout << endl;

	return 0;
}
