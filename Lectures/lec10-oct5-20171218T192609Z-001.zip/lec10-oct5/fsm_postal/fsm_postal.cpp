#include <Arduino.h>

/*
	Returns true if str is a valid postal code, as discussed in the lecture.

	That is, a valid postal code is of the form LNL NLN where L is an upper case
  letter and N is a single digit. There can be an arbitrary number of spaces
	before, after, and between the two parts (even 0 spaces).
*/
bool validPostal(const char* str) {
	enum State { L1, D1, L2, D2, L3, D3, DONE, ERR };

	State currentState = L1;

	int i = 0;
	while (true) {
		// can swap this out for a waitOnSerial3() call
		char c = str[i];
		i++;
		if (c == '\0') {
			break;
		}

		// FSM control

		if      (currentState == L1 && isupper(c)) { currentState = D1; }
		else if (currentState == L1 && c == ' ')   { ; } // do nothing
		else if (currentState == D1 && isdigit(c)) { currentState = L2; }
		else if (currentState == L2 && isupper(c)) { currentState = D2; }
		else if (currentState == D2 && isdigit(c)) { currentState = L3; }
		else if (currentState == D2 && c == ' ')   { ; }
		else if (currentState == L3 && isupper(c)) { currentState = D3; }
		else if (currentState == D3 && isdigit(c)) { currentState = DONE; }
		else if (currentState == DONE && c == ' ') { ; }
		else                                       { currentState = ERR; }
	}

	return currentState == DONE;
}

void testValidPostalSingle(const char* str, bool expected) {
	bool returned = validPostal(str);
	if (returned != expected) {
		Serial.print("Error on string: ");
		Serial.println(str);
		Serial.print("Expected: ");
		Serial.println(expected);
		Serial.print("Received: ");
		Serial.println(returned);
		Serial.println("---------------------------------");
	}
}

void testValidPostal() {
	Serial.println("Starting tests");
	testValidPostalSingle("T6G 2R3", true);
	testValidPostalSingle("T6g 2R3", false);
	testValidPostalSingle("      A1B     2C3     ", true);
	testValidPostalSingle("      A1B     2C3    X", false);
	testValidPostalSingle("T6G2R3", true);
	testValidPostalSingle("T6G2 R3", false);
	testValidPostalSingle("1A2B3C", false);
	testValidPostalSingle("", false);
	testValidPostalSingle("T6G 2R", false);
	testValidPostalSingle("T6G 2RZ", true); // testing the tester, should see output
	Serial.print("Done tests");
}

void setup() {
	init();
	Serial.begin(9600);
}

int main() {
	setup();

	testValidPostal();

	Serial.end();

	return 0;
}
