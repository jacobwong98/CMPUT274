#include <iostream>
#include <stdlib.h>
#include <assert.h>

using namespace std;

int main()
{
	int n;
	cin >> n;
	assert( 1 <= n );
	assert( n <= 100000 );

	int i, max, num, min, tumble, maxTumble;
	cin >> max;
	min = max;
	tumble = 0;
	maxTumble = 0;
	for( i = 1; i < n; i++ )
	{
		cin >> num;

		// New max
		if( num > max )
		{
			max = num;
		}
		// New min
		if( num < min )
		{
			min = num;
		}
	}
	cout << maxTumble << endl;
}
