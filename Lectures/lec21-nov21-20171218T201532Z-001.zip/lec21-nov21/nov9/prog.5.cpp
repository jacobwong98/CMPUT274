#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

using namespace std;

int * A[ 8 ];

int main()
{
    cout << "A: " << A << endl;
    cout << "A: " << &A << endl;
    cout << "A: " << A[ 0 ] << endl;
    cout << "A: " << &( A[ 0 ] ) << endl;

    cout << "**************************" << endl;

    for( int i = 0; i < 8; i++ )
    {
        // calloc = malloc + memset
        A[ i ] = (int*)calloc(4, sizeof( int ) );

        cout << "A: " << A[ i ] << endl;
    }

    cout << "--------------------------" << endl;

    for( int i = 0; i < 8; i++ )
    {
        free( (void*)A[ i ] );

        cout << "A: " << A[ i ] << endl;
    }

    return 0;
}
