#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

using namespace std;

int * A;

int main()
{
    int B[ 10 ];
    int C = 2;

    // calloc = malloc + memset
    A = (int*)malloc(4 * sizeof( int ) );
    memset( A, 0, ( 4 * sizeof( int ) ) );

    memset( B, 0, sizeof( B ) );

    cout << "A: " << A << endl;
    cout << "A: " << &A << endl;
    cout << "A: " << A[ 0 ] << endl;
    cout << "A: " << &( A[ 0 ] ) << endl;

    cout << "B: " << B << endl;
    cout << "B: " << &B << endl;
    cout << "B: " << B[ 0 ] << endl;
    cout << "B: " << &( B[ 0 ] ) << endl;

    cout << "C: " << C << endl;
    cout << "C: " << &C << endl;

    free( (void*)A );

    return 0;
}
