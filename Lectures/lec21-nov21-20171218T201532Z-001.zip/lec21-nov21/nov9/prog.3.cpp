#include <iostream>
#include <stdlib.h>
#include <assert.h>

using namespace std;

int * A;

int main()
{
    A = (int*)malloc(4 * sizeof( int ) );

    cout << (int **)&A << endl;

    return 0;
}
