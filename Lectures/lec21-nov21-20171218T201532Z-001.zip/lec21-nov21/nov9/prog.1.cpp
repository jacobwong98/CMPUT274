#include <stdlib.h>
#include <assert.h>

using namespace std;

int main()
{
    int a[ 4 ];

    return 0;
}
