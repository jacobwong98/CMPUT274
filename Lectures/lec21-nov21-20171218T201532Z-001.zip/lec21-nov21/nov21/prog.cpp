#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "stack.h"

// Original by Chris.  Check for matching paren and bracket.

using namespace std;

bool isBalanced(const char *str) {
  Stack s;
  for (unsigned int i = 0; i < strlen(str); ++i) {
    if (str[i] == '(' || str[i] == '[') {
      s.push(str[i]);
    }
    else {
      if (s.isEmpty())
        return false;
      if (str[i] == ')' && s.top() != '(')
        return false;
      if (str[i] == ']' && s.top() != '[')
        return false;
      s.pop();
    }
  }
  return s.isEmpty();
}


int main() {
  const char *A = "([](([[()]])))";
  const char *B = "(((()))[]]";

  cout << "Hello\n";
  cout << isBalanced(A) << endl;
  cout << isBalanced(B) << endl;

  return 0;
}
