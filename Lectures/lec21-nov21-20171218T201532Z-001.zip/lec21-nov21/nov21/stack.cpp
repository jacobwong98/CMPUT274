#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "stack.h"

Stack::Stack() {
  // Based on arrays
  topIdx = -1;
  arr = new int[4];
  arrSize = 4;
}

Stack::~Stack() {
  delete[] arr;
}

bool Stack::isEmpty() {
  return topIdx < 0;
}

int Stack::top() {
  assert(!isEmpty());
  return arr[topIdx];
}

void Stack::pop() {
  assert(!isEmpty());
  topIdx--;
}

void Stack::push(int item) {
  topIdx++;
  if (topIdx >= arrSize) {
    int *tmp = new int[2*arrSize];
    // Copy old items to tmp
    for (int i = 0; i < arrSize; ++i) {
      tmp[i] = arr[i];
    }
    delete[] arr;
    arr = tmp;
    arrSize = 2*arrSize;
  }

  arr[topIdx] = item;
}
