#ifndef STACK_H
#define STACK_H

class Stack {
public:
  /** Index of the top item, or -1 if stack is empty. */
  int topIdx;
  /** Dynamically allocated array */
  int *arr;
  /** Size of arr */
  int arrSize;

  Stack();
  ~Stack();
  bool isEmpty();
  int top();
  void pop();
  void push(int item);
};

#endif
