#include <iostream>

using namespace std;

// computes n! ("n factorial")
int factorial(int n) {
	if (n == 0) {
		return 1;
	}
	else {
		return n * factorial(n-1);
	}
}

// nonsense function that uses a lot of space
int gluttonous(int n) {
	int somearray[10000];
	somearray[0] = n/2;
	somearray[9999] = n;
	if (n == 0) return 0;
	return gluttonous(n-1) + somearray[0] + somearray[9999];
}

void printBackwards(const char* str) {
	if (*str) {
		printBackwards(str+1);
		cout << (*str);
	}
}

long long fib(long long n) {
	if (n == 0)  {
		return 0;
	}
	else if (n == 1) {
		return 1;
	}
	else {
		long long left = fib(n-2);
		long long right = fib(n-1);
		return left+right;
	}
}

// print instructions to solve the towers of Hanoi using k disks
// use the default peg values (1,3,2) if they are not specified
// # of instructions printed is 2^k - 1
void solveHanoi(int k, int start = 1, int end = 3, int inter = 2) {
	if (k == 0) {
		return;
	}

	solveHanoi(k-1, start, inter, end);
	cout << "move to of peg " << start << " to peg " << end << endl;
	solveHanoi(k-1, inter, end, start);
}

int main() {
	cout << "Factorials from 0! to 12!" << endl;
	for (int i = 0; i <= 12; i++) {
		cout << i << "! = " << factorial(i) << endl;
	}

	cout << endl;

	cout << "Printing 'hello world' backwards" << endl;
	printBackwards("hello world");
	cout << endl;

	cout << endl;
	cout << "Printing fibonacci numbers up to 20" << endl;
	for (long long i = 0; i <= 20; i++) {
		cout << "fib(" << i << ") = " << fib(i) << endl;
	}

	// too slow
	// cout << fib(50) << endl;

	// example of stack overflow
	// cout << factorial(10000000) << endl;

	// not very deep, but the function uses a lot of space so we can't recurse as deep
	// cout << gluttonous(1000) << endl;

	cout << endl;

	solveHanoi(4);

	return 0;
}
