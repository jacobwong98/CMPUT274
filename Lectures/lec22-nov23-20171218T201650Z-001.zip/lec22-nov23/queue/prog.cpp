#include <iostream>
#include <stdlib.h>
#include <assert.h>

#include "queue.h"

using namespace std;

int main() {
  Queue q;
  q.append(10);
  q.append(20);
  q.append(30);
  q.append(40);
  q.append(50);
  q.append(60);

  while (!q.isEmpty()) {
    cout << q.getHead() << endl;
    q.deleteAtHead();
  }

  return 0;
}
