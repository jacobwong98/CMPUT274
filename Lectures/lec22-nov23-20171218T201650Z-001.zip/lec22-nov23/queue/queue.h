#ifndef QUEUE_H
#define QUEUE_H

// Original from Chris Martin

struct QueueItem {
  int val;
  QueueItem *next;
};

class Queue {
public:
  QueueItem *head;
  QueueItem *tail;

  Queue();
  ~Queue();

  bool isEmpty();
  int getHead();
  void append(int item);
  int deleteAtHead();
};

#endif
