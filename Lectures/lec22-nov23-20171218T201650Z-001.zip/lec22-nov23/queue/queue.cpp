// Original from Chris Martin
#include <iostream>
#include <stdlib.h>
#include <assert.h>

#include "queue.h"

using namespace std;

// Ctor
Queue::Queue() {
  head = NULL;
  tail = NULL;
}

// Dtor
Queue::~Queue() {
  while (!isEmpty())
    deleteAtHead();
}

bool Queue::isEmpty() {
  return head == NULL;
}

int Queue::getHead() {
  assert(!isEmpty());
  return head->val;
}

void Queue::append(int item) {
  QueueItem *tmp = new QueueItem; // New **struct**
  tmp->val = item;	// No ctor.  Init here.
  tmp->next = NULL;

  if (head == NULL) {	// Special case
    assert(tail == NULL);
    head = tmp;		// First object in queue
  }
  else {
    tail->next = tmp;	// Link in at tail
  }
  tail = tmp;	// New object is tail
}

int Queue::deleteAtHead() {
  assert(!isEmpty());
  int res = head->val;

  QueueItem *tmp = head;
  head = tmp->next;	// Unlink head
  delete tmp;
  if (head == NULL)
    tail = NULL;

  return res;
}
