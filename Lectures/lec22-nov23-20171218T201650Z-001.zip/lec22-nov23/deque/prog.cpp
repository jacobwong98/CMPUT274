#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "deque.h"

using namespace std;

int main() {
  cout << "hello world!\n";

  Deque d;

  cout << "have empty deque\n";

  d.insertFront(200);
  d.insertBack(300);
  d.insertBack(400);
  d.insertFront(100);
  d.insertBack(500);

  while(!d.isEmpty()) {
    cout << d.front() << endl;
    d.deleteFront();
  }

  cout << "have empty deque\n";

  d.insertFront(200);
  d.insertBack(300);
  d.insertBack(400);
  d.insertFront(100);
  d.insertBack(500);

  while(!d.isEmpty()) {
    cout << d.back() << endl;
    d.deleteBack();
  }
  return 0;
}
