/*
	Skeleton of an Arduino program that has three LEDs that light up in sequence
	(wrapping around once the sequence is done).

	The order the LEDs light up should be flipped each time the button is released
	from being pressed.
*/

#include <Arduino.h>

const int ledPin[] = {10, 11, 12};
const int buttonPin = 5;

void setup() {
	// TODO: initialize Arduino functionality, remember what we need?

	// TODO: initialize the three LED pins as output
	// Can you do it with a loop and only type pinMode once for this step?

	pinMode(buttonPin, INPUT_PULLUP);
}

/*
	Given the index of which LED is currently lit up, return the index of the
	next LED that should be illuminated.

	Note, as you progress through this exercise you may have to add additional
	parameters to the function (in addition to "int lit").

	e.g.
	int nextLED(int lit, int someHelpfulParameter)
*/
int nextLED(int lit) {
	// right now, this just flips the LED between
	if (lit == 0) {
		return 1;
	}
	else {
		return 0;
	}
}

int main() {
	// what's missing here?

	int lit = 0;
	while (true) {
		/* TODO: - Have the LEDs illuminate in sequence,
		           not just back and forth between two of them.
		         - Introduce a variable that keeps track of whether the LED sequence
						   should go forward or backward.
						 - Flip the order of the sequence by pressing a button

			 Introduce any other variables you think might be necessary.
		*/

		// turn off the LED that is lit up
		digitalWrite(ledPin[lit], LOW);

		// now determine which LED should light up next
		lit = nextLED(lit);

		// now light up the next LED
		digitalWrite(ledPin[lit], HIGH);

		delay(250);
	}

	return 0;
}
