/*
	Author: Zachary Friggstad
	Student ID: 1111111

	A simple Arduino program that blinks an LED 4 times/second while a push button
	is being depressed.
*/

#include <Arduino.h>

// ANNOTATION: if the variable name is descriptive enough and it serves
// a simple purpose, there is no need for an additional comment
const int ledPin = 13;
const int buttonPin = 5;

// initialize Arduino functionality and the pin modes
void setup() {
	init();

	pinMode(ledPin, OUTPUT);
	pinMode(buttonPin, INPUT_PULLUP);
}

int main() {
	setup();

	// ANNOTATION: the purpose of the variable below is maybe more complicated
	// than what can be summarized in a simple name, so we should add a brief
	// comment describing its purpose
	int ledState = LOW; // should the LED be on or off

	while (true) {
		if (digitalRead(buttonPin) == LOW) {
			// if the button is pressed then toggle the status of the LED
			if (ledState == LOW) {
				ledState = HIGH;
			}
			else {
				ledState = LOW;
			}
		}
		else {
			// if the button is not pressed just turn the LED off
			ledState = LOW;
		}

		digitalWrite(ledPin, ledState);
		delay(125); // blinks 4 times per second when the button is pressed
	}

	return 0;
}
