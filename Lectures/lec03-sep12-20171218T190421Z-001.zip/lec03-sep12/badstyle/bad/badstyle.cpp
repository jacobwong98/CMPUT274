// by Zac
#include <Arduino.h>

int x = 13; // an LED
int y = 5; // a push button
int z; // is the LED on?

int main() {
init();
pinMode(x, OUTPUT);
pinMode(y, INPUT_PULLUP);

while (true) {
if (digitalRead(y) == LOW) {
if (z == LOW) z = HIGH;
else z = LOW; }
else
z = LOW;

digitalWrite(x, z);
delay(125);
}
}
