/*
	Demonstrating some graphics library functions.

	See adafruit-gfx-graphics-library.pdf on eClass (associated with Lecture 11),
	for more details on these and other functions in the graphics library.

	By default, the display has a width of 240 pixels and a height of 320 pixels.

	However: the orientation we will use for the assignment is horizontal
	so one should think of the width as 320 and the height as 240. This is why
	we do tft.setRotation(3);
*/

#include <Arduino.h>

// The Adafruit_ILI9341 class from here inherits from the Adafruit_GFX class,
// which implements the graphics library functions.
#include <Adafruit_ILI9341.h>

// TFT display and SD card will share the hardware SPI interface.
// For the Adafruit shield, these are the default.
// The display uses hardware SPI, plus #9 & #10
// Mega2560 Wiring: connect TFT_CLK to 52, TFT_MISO to 50, and TFT_MOSI to 51
#define TFT_DC 9
#define TFT_CS 10
#define SD_CD 6


// height is 240, width is 320 when oriented horizontally
#define TFT_HEIGHT 240
#define TFT_WIDTH 320

// Use hardware SPI (on Mega2560, #52, #51, and #50) and the above for CS/DC
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC);

void setup() {
	init();

	Serial.begin(9600);

	// Initialize the breakout board.
	// Required for both the display and the SD card.
	tft.begin();

	// because we hold it horizontally
	tft.setRotation(3);
}

int main() {
	setup();

	// fill the screen with the given colour
	// you can find all ILI9341_x colours in the header file Adafruit_ILI9341.h,
	// located in ~/arduino-ua/libraries/Adafruit_ILI9341/
	tft.fillScreen(ILI9341_BLACK);

	tft.drawPixel(TFT_WIDTH/2, TFT_HEIGHT/2, ILI9341_WHITE);


	// specify red, green, and blue intensities as values between 0 and 255
	uint16_t customColour = tft.color565(255, 0, 0);
	tft.drawLine(100, 100, 200, 200, customColour);
	// the custom colour is red!

	uint16_t customColour2 = tft.color565(255, 255, 0);
	tft.drawLine(100, 200, 200, 100, customColour2);
	// should be yellow

	// experiment with more colours, using intermediate intensities
	// e.g. what colour is tft.color565(255, 127, 0)?

	tft.println(1234);
	tft.setTextSize(2);
	tft.println("Hello");
	tft.setTextColor(customColour, customColour2);
	tft.setCursor(30, 12);
	tft.println("All done");

	Serial.end();

	return 0;
}
