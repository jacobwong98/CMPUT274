/*
	Simple program that reads a string from the serial monitor
	representing an integer and constructs the actual "int".
*/

#include <Arduino.h>

void setup() {
	init();
	Serial.begin(9600);
}

/*
	Given an array of characters s of length len.
	Reads character from the serial monitor until len-1 are
	read or '\r' is encountered and stores them sequentially in s[].
	Adds the null terminator to s[] at the end of this sequence.
*/
void readString(char str[], int len) {
	int index = 0;
	while (index < len - 1) {
		// if something is waiting to be read
		if (Serial.available() > 0) {
			char byteRead = Serial.read();
			// did the user press enter?
			if (byteRead == '\r') {
				break;
			}
			else {
				str[index] = byteRead;
				index += 1;
			}
		}
	}
	str[index] = '\0';
}

// read an integer from the serial monitor by reading
// characters until enter is pressed
uint32_t readUnsigned32() {
	char str[32];
	readString(str, 32);
	return atol(str);
	// Tricky question: why does this work even when entering 4,000,000,000
	// which fits in an unsigned long but not a signed long (as atol returns)?
}

int main() {
	setup();

	while (true) {
		uint32_t number = readUnsigned32();

		Serial.print("I read integer: ");
		Serial.println(number);
	}

	/*
		Alternative to Serial.flush().
		Main difference: the serial port is no longer available, you have to call
		Serial.begin(9600) again if you want to use it. Useful if you want to use
		the TX0/RX0 pins for something else, but we never have to.
	*/
	Serial.end();

	return 0;
}
