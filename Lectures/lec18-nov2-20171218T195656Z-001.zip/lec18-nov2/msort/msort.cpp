#include <iostream>
#include <cstdlib>
#include <cassert>

#define MAXN 1000000

using namespace std;

int auxArray[MAXN];

/*
	Assumes a and b are already sorted and that c[]
	has size at least na+nb. Computes the sorted array
	obtained by merging a (of size na) and b (of size nb),
	this is stored in c.
*/
void merge (int a[], int na, int b[], int nb, int c[]) {
	int ia = 0, ib = 0, ic = 0;

	// ia - index into a[] of the first item not yet in c[]
	// ib - index into b[] of the first item not yet in c[]
	// ic - index into c[] of the first unused space (i.e. # put in c so far)

	while (ia < na && ib < nb) {
		if (a[ia] <= b[ib]) {
			c[ic] = a[ia];
			ia++;
			ic++;
		}
		else {
			c[ic] = b[ib];
			ib++;
			ic++;
		}
	}

	// now either ia == na or ib == nb
	while (ia < na) {
		c[ic] = a[ia];
		++ia;
		++ic;
	}

	while (ib < nb) {
		c[ic] = b[ib];
		++ib;
		++ic;
	}

}

bool isSorted(int c[], int nc) {
	for (int i = 1; i < nc; i++) {
		if (c[i-1] > c[i]) {
			return false;
		}
	}

	return true;
}

void testMergeSingle(int a[], int na, int b[], int nb, int c[], int expected[]) {
	merge(a, na, b, nb, c);

	bool ok = true;
	for (int i = 0; i < na+nb; i++) {
		if (c[i] != expected[i]) {
			ok = false;
		}
	}

	if (!ok) {
		cout << "Error in merge" << endl;
		cout << "Expected:";
		for (int i = 0; i < na+nb; i++) {
			cout << ' ' << expected[i];
		}
		cout << endl;
		cout << "Got:     ";
		for (int i = 0; i < na+nb; i++) {
			cout << ' ' << c[i];
		}
		cout << endl;
	}
}

void testMerge() {
	cout << "Testing merge" << endl;
	// add some tests for the merge() operation

	int a1[] = {1, 3, 4, 8, 9};
	int b1[] = {2, 2, 4};
	int c1[8]; // 8 is the size of a + the size of b
	int expected1[] = {1, 2, 2, 3, 4, 4, 8, 9};
	testMergeSingle(a1, 5, b1, 3, c1, expected1);

	int a2[] = {};
	int b2[] = {1, 2, 3};
	int c2[3];
	int expected2[] = {1, 2, 3};
	testMergeSingle(a2, 0, b2, 3, c2, expected2);

	int a3[] = {-7, -3, -1, 0};
	int b3[] = {-2, -2, -1, 3};
	int c3[8];
	int expected3[] = {-7, -3, -2, -2, -1, -1, 0, 3};
	testMergeSingle(a3, 4, b3, 4, c3, expected3);

	int a4[] = {};
	int b4[] = {};
	int c4[0];
	int expected4[] = {};
	testMergeSingle(a4, 0, b4, 0, c4, expected4);

	cout << "Done!" << endl;
}


// NOTE: don't worry about implementing msort itself until we come to it in the lecture!

// merge sort: sort the array a[] of length n
void msort (int a[], int n) {
	// base case, an array of size <= 1 is already sorted
	if (n <= 1)  {
		return;
	}

	// split the array in half and recurse
	int mid = n/2;
	msort(a, mid);
	msort(a+mid, n-mid);

	merge(a, mid, a+mid, n-mid, auxArray);

	for (int i = 0; i < n; i++) {
		a[i] = auxArray[i];
	}
}


void testSingle(int array[], int n, int expected[])  {
	msort(array, n);

	bool ok = true;
	for (int i = 0; i < n; i++) {
		if (array[i] != expected[i]) {
			ok = false;
		}
	}

	if (!ok) {
		cout << "Error in sorting" << endl;
		cout << "Expected:";
		for (int i = 0; i < n; i++) {
			cout << ' ' << expected[i];
		}
		cout << endl;
		cout << "Got:     ";
		for (int i = 0; i < n; i++) {
			cout << ' ' << array[i];
		}
		cout << endl;
	}
}

void testSort() {
	cout << "Testing msort" << endl;
	int  a[] = {17, 3, -2, -5, 0, 5, 8, 4};
	int ea[] = {-5, -2, 0, 3, 4, 5, 8, 17};
	testSingle(a, 8, ea);

	int  b[] = {5};
	int eb[] = {5};
	testSingle(b, 1, eb);

	int  c[] = {1, 1, 1, 1, 1, 1};
	int ec[] = {1, 1, 1, 1, 1, 1};
	testSingle(c, 6, ec);

	int  d[] = {};
	int ed[] = {};
	testSingle(d, 0, ed);
	cout << "Done" << endl;
}


void testBig(int n) {
	int array[MAXN];

	for (int i = 0; i < n; i++) {
		array[i] = rand();
	}

	msort(array, n);

	if (!isSorted(array, n)) {
		cout << "Error: array of size << " << n
			   << " not sorted in testBig" << endl;
	}
}

int main(int argc, char** argv) {
	//testSort();

	if (argc != 2) {
		cout << "Usage: msort <# of values to sort>" << endl;
		exit(-1); // stop: return -1 to indicate it was not used correctly
	}

	int n = atoi(argv[1]);

	// make sure we only test with sizes at most our array size
	assert(0 <= n && n <= MAXN);

	testBig(n);

	return 0;
}
