#include <iostream>
#include <algorithm> // for max()

using namespace std;

int main() {
  // declare your variables

  // read the input

  // compute the answer

  // output the answer

  return 0;
}
