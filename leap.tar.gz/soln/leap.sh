#!/bin/bash
g++ -Wall -Werror leap.cpp -o leap && ./leap
rm ./leap
