#include <iostream>

using namespace std;

int main() {
  int year;
  cin >> year;

  // Put your code here!

  return 0;
}
