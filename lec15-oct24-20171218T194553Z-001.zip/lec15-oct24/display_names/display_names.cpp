/*
	Display a scrollable list of names on the screen.
*/

#include <Arduino.h>
#include <Adafruit_ILI9341.h>


#define TFT_DC 9
#define TFT_CS 10
#define SD_CS 6

Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC);

#define DISPLAY_WIDTH  320
#define DISPLAY_HEIGHT 240

#define JOY_VERT  A1
#define JOY_HORIZ A0
#define JOY_SEL   2

#define JOY_CENTER   512
#define JOY_DEADZONE 64

#define NUM_NAMES 13

const char* stringsToDisplay[] = {
	"Zac", "Paul", "Jason", "Jesse", "Zach", "Veronica",
	"A Very Long Name That Should Not Wrap Around",
	"Reyhaneh", "Taher", "Mohammad", "Somjit", "Everton", "Robert"
};

int highlightedString;

// assumes the text size is already 2, text is not wrapping,
// and that 0 <= index < NUM_NAMES
void drawName(int index) {
	// 15 is the vertical span of a size-2 character
	// (including the one pixel of padding below)
	tft.setCursor(0, 15*index);

	if (index == highlightedString) {
		tft.setTextColor(ILI9341_BLACK, ILI9341_WHITE);
	}
	else {
		tft.setTextColor(ILI9341_WHITE, ILI9341_BLACK);
	}
	tft.println(stringsToDisplay[index]);
}

void displayAllNames() {
	tft.fillScreen(ILI9341_BLACK);

	tft.setTextSize(2); // should use text size 1 for the assignment
	tft.setTextWrap(false);

	for (int index = 0; index < NUM_NAMES; index++) {
		drawName(index);
	}
}

void setup() {
	init();

	Serial.begin(9600);

	pinMode(JOY_SEL, INPUT_PULLUP);

	tft.begin();

	tft.fillScreen(ILI9341_BLACK);

	tft.setRotation(3);
}

int main() {
	setup();

	highlightedString = 0;
	displayAllNames();

	for (highlightedString = 1; highlightedString < NUM_NAMES; highlightedString++) {
		delay(1000);
		// draw the old highlighted string normally
		drawName(highlightedString-1);
		// highlight the new string
		drawName(highlightedString);
	}

	Serial.end();

	return 0;
}
