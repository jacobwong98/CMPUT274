/*
	NOTE: this is not a standalone program. You will have to add a
	main() function and whatever else is appropriate to try running
	these functions. This is simply here for the purposes of
	illustration.

	Quick O() notation refresher. We use O() to describe how the
	running time scales with the input size. It suppresses
	"constant" factors and "low order terms".

	e.g. if the running time of a function with an input of size n
	is 5n^2 + 3n (read, "5 times n squared plus 3 times n"), then
	we simply say the running time is O(n^2).

	For an algorithm that is comprised of just some nested for loops
	(with a "constant" amount of work done per iteration), we can
	say the O() running time is the number of iterations.
*/

/*
	The O() running time of this function is: O(n)

	Returns the maximum value in the array.
*/
int findMax(int* array, int n) {
	int maxVal = array[0];
	for (int i = 1; i < n; i++) {
		if (array[i] > maxVal) {
			maxVal = array[i];
		}
	}
	return maxVal;
}

/*
	The O() running time of this function is: O(n^3)

  Given an array with, possibly, positive and negative integers,
	this computes the largest possible sum of a consecutive subarray.
	e.g. the maximum value of array[i] + array[i+1] + ... + array[j]
     that can be obtained by some pair of indices
		 0 <= i <= j <= n-1.
	If all entries of array are negative, this returns 0.

	Example: array = {3, -4, 1, 5, -3, 6, -4, 3}
	The answer is 9 (from the subsequence 1, 5, -3, 6)

	Challenge: find a faster implementation with a better O()
	running time (i.e. improve the running time by more than a
	constant factor).
*/
bool maxSumSubarray(int* array, int n) {
	int best = 0;

	// try all pairs of indices 0 <= i <= j <= n-1
	for (int i = 0; i < n; i++) {
		for (int j = i; j < n; j++) {

			// for each such pair, compute array[i] + ... + array[j]
			int sum = 0;
			for (int k = i; k <= j; k++) {
				sum += array[k];
			}

			// update the maximum if we have a better solution
			if (sum > best) {
				best = sum;
			}
		}
	}
	return best;
}
