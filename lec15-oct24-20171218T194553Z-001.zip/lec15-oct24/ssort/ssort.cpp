#include <Arduino.h>

void setup() {
	init();
	Serial.begin(9600);
}

void ssort(int* array, int n) {
	// TODO: implement selection sort!

}

void testSortSingle(int* array, int n, int* expected) {
	// implement a single test
}

void testSort() {
	// implement some tests
}

int main() {
	setup();

	testSort();

	Serial.end();
	return 0;
}
