#!/bin/bash
g++ manhattan.cpp -o manhattan -Wall && ./manhattan
rm -f ./manhattan
