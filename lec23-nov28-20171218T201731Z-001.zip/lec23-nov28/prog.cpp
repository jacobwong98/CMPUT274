#include <iostream>
#include <stdlib.h>
#include <assert.h>

#include "hashtable.h"

// Original by Chris Martin

using namespace std;

int main() {
  HashTable t(100);	// 100 is NOT a good choice in general

  cout << "Buckets: " << t.buckets << endl;
  cout << "Buckets[ 0 ]: " << t.buckets[0] << endl;

  t.set(1234567, "Joe Shmoe");
  t.set(7771122, "Pizza73");
  t.set(5789056, "Boston Pizzas");
  t.set(9999056, "Panago");
  cout << endl;

  t.print();
  cout << endl;

  cout << t.get(1234567) << endl;
  cout << t.get(7771122) << endl;
  cout << "Checking for 1122334:" << endl;
  cout << t.exists(1122334) << endl;

  t.remove(7771122);
  t.print();
  cout << endl;

  t.remove(5789056);
  t.print();
  cout << endl;

  cout << endl;

  return 0;
}
