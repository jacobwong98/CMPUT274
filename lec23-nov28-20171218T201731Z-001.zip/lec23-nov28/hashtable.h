#ifndef HASH_TABLE_H
#define HASH_TABLE_H

// Original by Chris Martin

// typedef const char* KeyType;
typedef int KeyType;
typedef const char* ValType;

struct HashItem {
  HashItem* next;
  KeyType key;
  const char *value;

  /** Initializes key, value, next = NULL */
  HashItem(KeyType key, const char* value);
  ~HashItem();
};

class HashTable {
public:
  HashItem** buckets;
  int nbuckets;

  HashItem* getItem(KeyType key);

public:
  /** Creates a new hash table with the given number of buckets. */
  HashTable(int nbuckets);
  ~HashTable();

  /** Returns the value assoicated with the given key, or NULL if not found. */
  const char* get(KeyType key);
  /** Sets the value of a given key, or creates it. */
  void set(KeyType key, const char* value);
  /** Returns true if the key exists */
  bool exists(KeyType key);
  /** Removes the key from the table. */
  void remove(KeyType key);

  void print();
};


#endif
