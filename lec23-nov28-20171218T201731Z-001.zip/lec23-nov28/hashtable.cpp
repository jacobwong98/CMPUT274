#include <iostream>
#include <stdlib.h>
#include <assert.h>

#include "hashtable.h"

// Original by Chris Martin

using namespace std;

// Hash function could be a lot more sophisticated
int hashFunc(KeyType key, int nbuckets) {
  return key % nbuckets;
}


HashItem::HashItem(KeyType key, const char *value) {
  this->key = key;
  this->value = value;
  this->next = NULL;
}

HashItem::~HashItem() {
  if (next != NULL)
    delete next;
}


HashTable::HashTable(int nbuckets) {
  this->nbuckets = nbuckets;
  this->buckets = new HashItem*[nbuckets];
  assert( this->buckets != NULL );

  for (int i = 0; i < nbuckets; ++i)
    buckets[i] = NULL;
}

HashTable::~HashTable() {
  for (int i = 0; i < nbuckets; ++i)
    if (buckets[i] != NULL)
      delete buckets[i];
  delete[] buckets;
}

void HashTable::print() {
  for (int h = 0; h < nbuckets; ++h) {
    if( buckets[h] != NULL ) {
      cout << h << ":" << endl;
    }
    for (HashItem *it = buckets[h]; it != NULL; it = it->next) {
      cout << "  [ " << it->key << ":";
      cout << it->value << " ]" << endl;
    }
  }
}

HashItem* HashTable::getItem(KeyType key) {
  int h = hashFunc(key, nbuckets);

  for (HashItem* it = buckets[h]; it != NULL; it = it->next) {
    if (it->key == key) {
      return it;
    }
  }

  return NULL;
}

const char* HashTable::get(KeyType key) {
  HashItem *it = getItem(key);
  if (it != NULL)
    return it->value;
  else
    return NULL;
}

bool HashTable::exists(KeyType key) {
  return get(key) != NULL;
}

void HashTable::set(KeyType key, const char *value) {
  HashItem *it = getItem(key);

  if (it != NULL) {
    // Update item.
    it->value = value;
  }
  else {
    // Create the item.
    int h = hashFunc(key, nbuckets);
    it = new HashItem(key, value);
    assert(it != NULL);
    it->next = buckets[h];
    buckets[h] = it;
  }
}

void HashTable::remove(KeyType key) {
  // Remove item corresponding to key from the table.
  int h = hashFunc(key, nbuckets);
  HashItem *it, *prev = NULL;
  for (it = buckets[h]; it != NULL; it = it->next) {
    if (it->key == key)
      break;
    prev = it;
  }
  // Found the item (hopefully)
  if (it == NULL)
    return; // didn't find the item
  else if (prev == NULL)
    // First item in the bucket
    buckets[h] = it->next;
  else
    // middle of the bucket
    prev->next = it->next;
  it->next = NULL;
  delete it;
}
