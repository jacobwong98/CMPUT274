/*
	Just a simple example of how to use the touch screen.
	The coordinates that were touched are displayed on the screen.
*/

#include <Arduino.h>
#include <Adafruit_ILI9341.h>
#include <TouchScreen.h>

// TFT display and SD card will share the hardware SPI interface.
// For the Adafruit shield, these are the default.
// The display uses hardware SPI, plus #9 & #10
// Mega2560 Wiring: connect TFT_CLK to 52, TFT_MISO to 50, and TFT_MOSI to 51
#define TFT_DC  9
#define TFT_CS 10
#define SD_CS   6

// touch screen pins, obtained from the documentaion
#define YP A2  // must be an analog pin, use "An" notation!
#define XM A3  // must be an analog pin, use "An" notation!
#define YM  5  // can be a digital pin
#define XP  4  // can be a digital pin

// width/height of the display when rotated horizontally
#define TFT_WIDTH  320
#define TFT_HEIGHT 240

// calibration data for the touch screen, obtained from documentation
// the minimum/maximum possible readings from the touch point
#define TS_MINX 150
#define TS_MINY 120
#define TS_MAXX 920
#define TS_MAXY 940

// thresholds to determine if there was a touch
#define MINPRESSURE   10
#define MAXPRESSURE 1000

Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC);

// a multimeter reading says there are 300 ohms of resistance across the plate,
// so initialize with this to get more accurate readings
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);

void setup() {
	init();

	// do not actually need to change the pinmode of the digital TouchScreen
	// pins, the function to get a touchscreen reading will set and change them

	Serial.begin(9600);

	tft.begin();

	tft.fillScreen(ILI9341_BLACK);

	tft.setRotation(3);

	tft.setTextSize(3);
	tft.println("Waiting for touch");
}

void checkTouch() {
	TSPoint touch = ts.getPoint();

	if (touch.z < MINPRESSURE || touch.z > MAXPRESSURE) {
		// no touch, just quit
		return;
	}

	// get the y coordinate of where the display was touched
	// remember the x-coordinate of touch is really our y-coordinate
	// on the display
	int touchY = map(touch.x, TS_MINX, TS_MAXX, 0, TFT_HEIGHT - 1);

	// need to invert the x-axis, so reverse the
	// range of the display coordinates
	int touchX = map(touch.y, TS_MINY, TS_MAXY, TFT_WIDTH - 1, 0);

	tft.fillScreen(ILI9341_BLACK);
	tft.setCursor(0, 0);
	tft.setTextSize(3);

	tft.println("Touch!");
	tft.print("x = ");
	tft.println(touchX);
	tft.print("y = ");
	tft.println(touchY);
	tft.print("z = ");
	tft.println(touch.z);
}

int main() {
	setup();

	while (true) {
		checkTouch();
	}

	Serial.end();

	return 0;
}
