#!/bin/bash
g++ addition.cpp -o addition -Wall && ./addition
rm -f ./addition
