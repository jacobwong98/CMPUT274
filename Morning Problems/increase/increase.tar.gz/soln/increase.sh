#!/bin/bash
g++ increase.cpp -o increase -Wall && ./increase
rm -f ./increase
