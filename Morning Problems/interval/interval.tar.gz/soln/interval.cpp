#include <iostream>

using namespace std;

int main() {
  int low1, high1, low2, high2;
  cin >> low1 >> high1 >> low2 >> high2;

  // now solve the problem and print the answer

  return 0;
}
