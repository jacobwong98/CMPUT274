#!/bin/bash
g++ interval.cpp -o interval -Wall && ./interval
rm -f ./interval
