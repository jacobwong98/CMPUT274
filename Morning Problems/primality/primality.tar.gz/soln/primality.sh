#!/bin/bash
g++ primality.cpp -o primality -Wall && ./primality
rm -f ./primality
