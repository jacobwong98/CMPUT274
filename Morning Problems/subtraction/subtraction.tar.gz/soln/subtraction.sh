#!/bin/bash
g++ subtraction.cpp -o subtraction -Wall && ./subtraction
rm -f ./subtraction
