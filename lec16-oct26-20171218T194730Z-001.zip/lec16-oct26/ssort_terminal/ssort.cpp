// compile with g++ ssort.cpp -o ssort -Wall

#include <iostream>
#include <cstdlib>  // for rand()
#include <cassert>

#define MAXN 1000000

using namespace std;

// swaps two integers
void swap(int& a, int& b) {
	int c = a;
	a = b;
	b = c;
}

// sort using selection sort
// running time: O(n^2)
void ssort(int array[], int n) {
	// divider is the index of the last value in the unsorted part
	// of the array
	for (int divider = n-1; divider > 0; divider--) {
		// now find the maximum value in the unsorted part
		// scan one at a time, recording the position of the
		// maximum seen so far
		int maxpos = 0;

		// after iteration j, maxpos should store the index
		// of the maximum value up to (and including) position j
		for (int j = 1; j <= divider; j++) {
			if (array[j] > array[maxpos]) {
				maxpos = j;
			}
		}

		swap(array[maxpos], array[divider]);
	}
}

void testSingle(int array[], int n, int expected[])  {
	ssort(array, n);

	bool ok = true;
	for (int i = 0; i < n; i++) {
		if (array[i] != expected[i]) {
			ok = false;
		}
	}

	if (!ok) {
		cout << "Error in sorting" << endl;
		cout << "Expected:";
		for (int i = 0; i < n; i++) {
			cout << ' ' << expected[i];
		}
		cout << endl;
		cout << "Got:     ";
		for (int i = 0; i < n; i++) {
			cout << ' ' << array[i];
		}
		cout << endl;
	}
}

void testSort() {
	int  a[] = {17, 3, -2, -5, 0, 5, 8, 4};
	int ea[] = {-5, -2, 0, 3, 4, 5, 8, 17};
	testSingle(a, 8, ea);

	int  b[] = {5};
	int eb[] = {5};
	testSingle(b, 1, eb);

	int  c[] = {1, 1, 1, 1, 1, 1};
	int ec[] = {1, 1, 1, 1, 1, 1};
	testSingle(c, 6, ec);

	int  d[] = {};
	int ed[] = {};
	testSingle(d, 0, ed);
}

void testBig(int n) {
	int array[MAXN];

	for (int i = 0; i < n; i++) {
		array[i] = rand();
	}

	ssort(array, n);

	bool sorted = true;
	// check if it is sorted
	for (int i = 0; i+1 < n; i++) {
		if (array[i] > array[i+1]) {
			sorted = false;
		}
	}

	if (!sorted) {
		cout << "Error: array of size << " << n
			   << " not sorted in testBig" << endl;
	}
}

int main(int argc, char** argv) {
	//testSort();

	//testBig(200000);

	// cout << "There are " << argc << " arguments" << endl;
	// for (int i = 0; i < argc; i++) {
	// 	cout << argv[i] << endl;
	// }

	if (argc != 2) {
		cout << "Usage: ssort <# of values to sort>" << endl;
		exit(-1); // stop: return -1 to indicate it was not used correctly
	}

	int n = atoi(argv[1]);

	// make sure we only test with sizes at most our array size
	assert(0 <= n && n <= MAXN);

	testBig(n);

	return 0;
}
