#include <iostream>

using namespace std;

int main() {
  int d1, d2, d3, d4;

  cin >> d1 >> d2 >> d3 >> d4;

  // Put your code here!

  return 0;
}
