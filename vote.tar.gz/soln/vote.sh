#!/bin/bash
g++ vote.cpp -o vote -Wall && ./vote
rm -f ./vote
