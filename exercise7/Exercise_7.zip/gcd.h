// Header file that is used to be include the gcd.cpp file and the exercise7.cpp
#ifndef _GCD_H_
#define _GCD_H_

unsigned int gcd(unsigned int a, unsigned int b);

#endif
