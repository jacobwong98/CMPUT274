#include "Arduino.h"

void setup() {
	int ledPin = 13;
	init();
	pinMode(ledPin, OUTPUT);
}

int main(){

	while(true) {
		digitalWrite(ledPin, HIGH);
		delay(1000);
		digitalWrite(ledPin, LOW);
		delay(1000);
	}

	return 0;
}
