#include "Arduino.h"

int ledPin = 13;

void setup() {
	init();
	pinMode(ledPin, OUTPUT);
}

int main(){

	while(true) {
		digitalWrite(ledPin, HIGH);
		delay(1000);
		digitalWrite(ledPin, LOW);
		delay(1000);


	return 0;
}
