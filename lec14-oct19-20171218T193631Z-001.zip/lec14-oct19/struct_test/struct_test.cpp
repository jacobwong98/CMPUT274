#include <iostream>

using namespace std;

struct something {
	char a; // 1 byte, but 3 bytes are padding
	int b;  // 4 bytes
	char c; // 1 byte, but 3 bytes are padding again
};

int main() {
	something s;

	cout << sizeof(s) << endl;

	return 0;
}
