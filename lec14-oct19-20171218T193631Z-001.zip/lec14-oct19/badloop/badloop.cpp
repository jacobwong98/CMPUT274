/*
	Example of how bad indexing can mess up a program.
*/

#include <Arduino.h>

void setup() {
	init();
	Serial.begin(9600);
}

int main() {
	setup();

	int array[] = {6, 9, -2, 4, 5};

	for (int i = 0; i < 15; i++) {
		Serial.print(i);
		Serial.print(' ');
		Serial.println(array[i]);
		array[i] = 0;
		delay(250);
	}

	Serial.end();
	return 0;
}
