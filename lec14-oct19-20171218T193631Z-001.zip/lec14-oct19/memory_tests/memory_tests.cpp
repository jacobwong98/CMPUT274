/*
	Just some examples of how to use pointers, aliases, references, and dereferences.
*/

#include <Arduino.h>

void setup() {
	init();
  Serial.begin(9600);
}

void doubleFunction(uint32_t& var) {
	var *= 2;
}

int globalVar;

int main() {
	setup();

	const char* str = "hello";
	Serial.print("Address of string literal: ");
	Serial.println((uint16_t) str);
	Serial.print("Address of str pointer: ");
	Serial.println((uint16_t) &str);
	Serial.print("Address of global variable globalVar: ");
	Serial.println((uint16_t) &globalVar);
	Serial.println();

	uint32_t val = 8675309;
	uint32_t* ptr = &val;

	Serial.print("Address of the variable val: ");
	Serial.println((uint16_t) ptr);

	Serial.print("Another way to get the address of variable val: ");
	Serial.println((uint16_t) &val);

	Serial.print("Pointer variables have address too: ");
	Serial.println((uint16_t) &ptr);

	*ptr = 123456;
	Serial.print("Now val is: ");
	Serial.println(val);

	Serial.print("The pointer did not change: ");
	Serial.println((uint16_t) ptr);

	Serial.println();

	uint32_t& alias = val;
	alias = 55;
	Serial.print("Now val is: ");
	Serial.println(alias);

	Serial.print("The address of alias: ");
	Serial.println((uint16_t) &alias);

	// int negative = -4;
	// uint32_t* badptr = (uint32_t*) negative;
	// Serial.println(*badptr);

	Serial.println();

	uint32_t varToDouble = 7;
	Serial.print("varToDouble is: ");
	Serial.println(varToDouble);
	doubleFunction(varToDouble);
	Serial.print("After the function call, varToDouble is: ");
	Serial.println(varToDouble);

	Serial.println();

	// examples of where string literals and globals are placed

	uint32_t array[] = {1, 5, 7, 2, 8};
	uint32_t* ptr2 = &array[0];
	Serial.print("ptr2 is holding address: ");
	Serial.println((uint16_t) ptr2);
	ptr2 += 2;
	Serial.print("Now ptr2 is holding address: ");
	Serial.println((uint16_t) ptr2);
	Serial.print("The value being pointed at is: ");
	Serial.println(*ptr2);
	Serial.print("Size of a uint32_t: ");
	Serial.println(sizeof(array[0]));

	Serial.println();

	*(array+3) = 20; // same as array[3] = 20
	for (int i = 0; i < 5; ++i) {
		Serial.print(array[i]);
		Serial.print(" ");
	}
	Serial.println();


  Serial.end();

  return 0;
}
