// Student name: Jacob Wong
// CCID: jdw2
// Student ID: 1511712
#ifndef _string_processing_h_
#define _string_processing_h_
// declaration of all the functions
int getStringLength(const char* str);
void printBackward(const char* str);
void getStringLengthTest(const char* a, int expectedNum);
void testGetStringLength();

#endif
